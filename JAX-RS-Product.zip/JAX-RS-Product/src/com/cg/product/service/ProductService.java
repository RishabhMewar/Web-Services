package com.cg.product.service;

import java.util.List;

import com.cg.product.beans.Product;
import com.cg.product.dao.IProductDao;
import com.cg.product.dao.ProductDaoImpl;

public class ProductService implements IProductService {
	IProductDao dao;

	public ProductService() {
		dao = new ProductDaoImpl();
	}

	/**
	 * Fetching all details of countries
	 * 
	 * @return List<Country>
	 */
	public List<Product> getAllProducts() {
		return dao.getAllProducts();
	}

	/**
	 * Fetching single country details
	 * 
	 * @param id
	 * @return Country
	 */
	public Product getProduct(int id) {
		return dao.getProduct(id);
	}

	/**
	 * Creating a new Country
	 * 
	 * @param country
	 * @return Country
	 */
	public Product addProduct(Product product) {
		return dao.addProduct(product);
	}

	/**
	 * Deleting an existing country
	 * 
	 * @param id
	 * @return Country
	 */
	public Product deleteProduct(int id) {
		return dao.deleteProduct(id);
	}

}
