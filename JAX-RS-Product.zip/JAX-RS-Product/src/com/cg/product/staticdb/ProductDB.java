package com.cg.product.staticdb;

import java.util.HashMap;

import com.cg.product.beans.Product;

/**
 * 
 * @author yvalecha
 * Static DB class, hosting country details in a HashMap
 */
public class ProductDB {
	static HashMap<Integer, Product> productIdMap = getProductIdMap();
	
	static {
		if (productIdMap == null) {
			productIdMap = new HashMap<Integer, Product>();
			Product mobileProduct = new Product(1, "Mobile", 10000);
			Product tabProduct = new Product(4, "Tab", 20000);
			Product headphoneProduct = new Product(3, "HeadPhone", 8000);
			Product phoneProduct = new Product(2, "Phone", 7000);

			productIdMap.put(1, mobileProduct);
			productIdMap.put(4, tabProduct);
			productIdMap.put(3, headphoneProduct);
			productIdMap.put(2, phoneProduct);
		}

	}
	/**
	 * This is a getter method of HashMap
	 * @return HashMap<Integer, Country>
	 */
	public static HashMap<Integer, Product> getProductIdMap() {
		return productIdMap;
	}
}
