package com.cg.product.dao;

import java.util.List;

import com.cg.product.beans.Product;

public interface IProductDao {

	
	public List<Product> getAllProducts();
	public Product getProduct(int id);
	public Product addProduct(Product product);
	public Product deleteProduct(int id);
}

