package com.cg.product.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.product.beans.Product;
import com.cg.product.staticdb.ProductDB;

public class ProductDaoImpl implements IProductDao {

	static HashMap<Integer, Product> productIdMap =  ProductDB.getProductIdMap();
	
	public List<Product> getAllProducts() {
		List<Product> product = new ArrayList<Product>(productIdMap.values());
		return product;
	}

	
	public Product getProduct(int id) {
		Product product = productIdMap.get(id);
		return product;
	}


	public Product addProduct(Product product) {
		if (product.getProductId() <= 0)
			return null;
		productIdMap.put(product.getProductId(), product);
		return product;
	}

	
	public Product deleteProduct(int id) {
		return productIdMap.remove(id);
	}

}
